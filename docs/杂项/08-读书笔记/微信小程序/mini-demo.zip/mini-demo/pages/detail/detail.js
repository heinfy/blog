//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    // 普通选择器列表设置,及初始化
    rangekey: 0,//用于记录选择器的下标
    objectArray: [//选择器的对象数组
      { id: 0, name: '梨', price: 1 },
      { id: 1, name: '苹果', price: 2 },
      { id: 2, name: '火龙果', price: 3 },
      { id: 3, name: '苹果', price: 4 }
    ],
    // 省市区三级联动初始化
    region: ["四川省", "广元市", "苍溪县"],
    // 多列选择器(二级联动)列表设置,及初始化
    multiArray: [[1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 2, 3, 4, 5, 6, 7, 8, 9]],
    multiIndex: [3,5],
    // 多列选择器(三级联动)列表设置,及初始化
    multiArray3: [[1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 2, 3, 4, 5, 6, 7, 8, 9]],
    multiIndex3: [3, 5, 4]
  },
  onLoad: function (options) {
    console.log(options)
  },
  // 选择国家函数
  changeCountry(e){
    console.log(e.detail)
    this.setData({ rangekey: e.detail.value});
  },
  // 选择省市区函数
  changeRegin(e){
    this.setData({ region: e.detail.value });
  },
  // 选择二级联动
  changeMultiPicker(e) {
    this.setData({multiIndex: e.detail.value})
  },
  // 选择三级联动
  changeMultiPicker3(e) {
    this.setData({ multiIndex3: e.detail.value })
  }
})