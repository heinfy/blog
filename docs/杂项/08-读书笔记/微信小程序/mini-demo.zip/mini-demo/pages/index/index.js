//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    items: [
      {value: 'USA', name: '美国'},
      {value: 'CHN', name: '中国', checked: 'true'},
      {value: 'BRA', name: '巴西'},
      {value: 'JPN', name: '日本'},
      {value: 'ENG', name: '英国'},
      {value: 'FRA', name: '法国'}
    ],
    introInfo: [
      "http://wenba-ooo-qiniu.xueba100.com/0510d6b196f421cb415db9ef3eb9269c.png",
      "http://wenba-ooo-qiniu.xueba100.com/3346a4f0649e4b7c9e58d6f5ca70bf2c.png",
      "http://wenba-ooo-qiniu.xueba100.com/aec796aa4bbcbea0d6334f5ab5ee091d.png"
    ],
    motto: '去详情页面'
  },
  checkboxChange(e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value)
  },
  // 展示弹框
  showRules () {
    setTimeout(() => {
      this.setPopupStatus({el:'#popup', hidden: false })
    }, 150)
  },
  setPopupStatus({ el, hidden }) {
    let childDialog = this.selectComponent(el)
    childDialog.setData({
      isHidden: hidden
    })
  },
  // 点击X号关闭弹窗
  closeMask (e) {
    const child = this.selectComponent('#popup')
    console.log(child)
    console.log('点击X号', e)
  },
  onLoad: function () {
    app.login().then(res => {
      console.log('11111111')
    })
  },
  goDetail(){
    wx.navigateTo({
      url: `/pages/detail/detail?id=1&name=houfei`
    })
  },
  onPullDownRefresh: function() {
    wx.showToast({
      // 显示Toast
      title: '已发送',
      icon: 'success',
      duration: 1500
    })
    // 用户触发了下拉刷新操作
    // 拉取新数据重新渲染界面
    // wx.stopPullDownRefresh() // 可以停止当前页面的下拉刷新。

  },
  checkCode: () => {
    console.log('checkCode')
  }
})
