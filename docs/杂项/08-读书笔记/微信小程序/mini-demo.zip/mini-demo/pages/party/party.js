// party.js

Page({
  data: {
    info: '该模块努力开发ing~'
  },
  onLoad: function () {
    console.log('该模块努力开发ing~')
  }
})
