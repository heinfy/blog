Component({
  options: {
    styleIsolation: 'isolated', // 组件样式隔离
    // virtualHost: true, // 虚拟化组件节点，防止父组件样式干扰，注意父组件中使用this.selectComponent(el)将无效
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },
  // 组件传值
  properties: {
    // 这里定义了innerText属性，属性值可以在组件使用时指定
    innerText: {
      type: String,
      value: '默认值'
    }
  },
  // 私有属性
  data: {
    isHidden: true
  },
  // 组件数据字段监听器，用于监听 properties 和 data 的变化
  observers: {
    isHidden: function (isHidden) {
      this.triggerEvent('close-modal', { isHidden: isHidden })
    }
  },
  methods: {
    showModal() {
      this.setData({
        isHidden: false
      })
    },
    hideModal() {
      this.triggerEvent('closeMask', {
        a: 1
      })
      this.setData({
        isHidden: true
      })
    }
  },
  lifetimes: {
    // 生命周期函数，可以为函数，或一个在methods段中定义的方法名
    attached: function () {
      console.log('lifetimes-attached')
    },
    moved: function () {
      console.log('lifetimes-moved')
    },
    ready: function () {
      console.log('ready')
    },
    detached: function () {}
  },
  pageLifetimes: {
    // 组件所在页面的生命周期函数
    show: function () {
      console.log('pageLifetimes-show')
    },
    hide: function () {
      console.log('pageLifetimes-hide')
    },
    resize: function () {
      console.log('pageLifetimes-resize')
    }
  }
})
