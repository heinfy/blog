Component({
  data: {
    processObj: {
      0: 'https://wenba-ooo-qiniu.xueba100.com/8e55946efcf6a845b850e0675f99524e.png', // 未领取
      1: 'https://wenba-ooo-qiniu.xueba100.com/3670b936536780582dbdde79291dc75f.png', // 领取
      2: 'https://wenba-ooo-qiniu.xueba100.com/edf72335fee33fdc24658c8d000f5fce.png', // 助力中
      3: 'https://wenba-ooo-qiniu.xueba100.com/8d3ca3acb1211e9b43cb3989ccd11a1f.png', // 助力完成
      4: 'https://wenba-ooo-qiniu.xueba100.com/5b2b2e034a5aee0e56feb96e971a9a55.png' // 下载完成
    }
  },
  properties: {
    status: {
      type: Number,
      value: 0
    }
  }
})
