// src/components/countDown/index.js
import {countDownFun} from '../../utils/util'
const app = getApp();

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    endtime: {
      type: Number,
      observer: function(newVal,oldVal,changedPath){
        if(newVal) {
          const countDown = newVal.toString().length >= 13 ? newVal : newVal * 1000
          this.setCountDown(countDown)
        }
      }
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    days: '',
    hours: '',
    minutes: '',
    seconds: ''
  },
  /**
   * 组件的方法列表
   */
  methods: {
    setCountDown(countDown) {
      console.log('this.data.endtime', countDown)
      const end = countDown
      // const end = this.data.endtime.toString().length >= 13 ? this.data.endtime : this.data.endtime * 1000
      if(end) {
        countDownFun({
          endtime: end, 
          timerobj: app.globalData,
          callback: (res) => {
            const {days, hours, minutes, seconds} = res;
            // if(app.globalData.timer != timer) {
            //   app.globalData.timer = timer
            // }
            this.setData({
              days,
              minutes,
              hours,
              seconds
            })
            // console.log('timer', timer)
          }
        })
      }
    }
  }
})
