// src/components/countDown/index.js
import {sendFormId} from '../../api/index'
const app = getApp();

Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
  },
  /**
   * 组件的方法列表
   */
  methods: {
    formSubmit: function(e) {
        console.log('layout.formids',e.detail.formId)
        if("the formId is a mock one"!=e.detail.formId){
            let form_id = e.detail.formId
            if (form_id) {
              sendFormId({
                form_id
              }).then((res) => {
                console.log(res)
                if (res.data.success) {
        
                } else {
                  // wx.showToast({
                  //   title: '发送formid失败',
                  //   duration: 2000
                  // })
                }
              })
            }
        }
    },
  }
})
