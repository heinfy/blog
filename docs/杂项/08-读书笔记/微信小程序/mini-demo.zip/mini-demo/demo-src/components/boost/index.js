// src/components/boost/index.js
import {updateTimestamp} from '../../api/index'
import {getAddexpired} from '../../utils/util'
const app = getApp();

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    status: {
      type: Number,
      value:1
    },
    itemid: null,
    startTime: {
      type: null,
      observer:function(newVal,oldVal,changedPath){
        this.setData({
          _startTime: newVal,
          countDown: newVal
        })
        console.log('observer startTime', newVal)
        this._setcountDown()
      }
    },
    total: {
      type: null,
      observer:function(newVal,oldVal,changedPath){
        const len = +newVal
        const avatars = this.data.avatars
        let arr = []
        if(avatars.length) {
          for(let i = 0; i < len; i++) {
            if(avatars[i]) {
              arr[i] = avatars[i]
            } else {
              arr[i] = null
            }
          }
        } else {
          arr = new Array(len)
        }
        this.setData({
          _total: newVal,
          peoples: len,
          avatars: arr
        })
      }
    },
    hasBoostNum: {
      type: null,
      observer:function(newVal,oldVal,changedPath){
        this.setData({
          _hasBoostNum: newVal
        })
      }
    },
    boostMan: {
      type: Array,
      observer:function(newVal,oldVal,changedPath){
        const boostMan = newVal
        if(boostMan && boostMan.length) {
          let arr = this.data.avatars
          for(let i = 0; i < boostMan.length; i++) {
            arr[i] = boostMan[i]
          }
          this.setData({
            avatars: arr
          })
        }
      }
    },
    coverImg: null,
    expired: null,
    isFirst: {
      type: null,
      observer:function(newVal,oldVal,changedPath){
        let ishow = false
        if(newVal == 1) {
          ishow = false
        } else {
          ishow = true
        }
        this.setData({
          showAvatars: ishow
        })
      }
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    peoples: '',
    showAvatars: false,
    avatars: [],
    countDown: 0,
    timer: null,
    _startTime: null,
    _hasBoostNum: null,
    _boostMan: [],
    _total: null
  },

  attached() {
    // this.setData({
    //   avatars: new Array(this.data.total.len)
    console.log('arr1',this.boostMan)

    // })
  },
  onLoad(){

  },
  /**
   * 组件的方法列表
   */
  methods: {
    _setcountDown() {
      let countDown = this.data.countDown;
      // if(!this.data.expired) {
      //   this.data.expired = 24
      // }
      // const endtime = getAddexpired(countDown, +this.data.expired)
      this.setData({
        countDown: countDown
      })
    },
    _updateTimestamp() {
      const params = {
        data: {
          power_id: app.globalData.powerId
        }
      }
      console.log('_updateTimestamp', this.data)
      updateTimestamp(params)
      .then(res => {})
      .catch(err => {})
    }
  }
})
