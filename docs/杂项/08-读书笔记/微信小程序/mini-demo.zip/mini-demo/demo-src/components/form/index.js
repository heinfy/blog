// components/form.js
import {submitForm, sendFormId,sendValidateCode,checkValidateCode} from '../../api/index'
const app = getApp();
Component({
  options: {
    addGlobalClass: true,
  },
  /**
   * 组件的属性列表
   */
  properties: {
    item: Object,
    tip: {
      type: String,
      value: '领取成功!'
    },
    isBoost: Boolean,
    gradeData: {
      type: null,
      observer:function(newVal,oldVal,changedPath){
        const arr = this.formateData2Arr(newVal)
        console.log('arr', arr)
        this.setData({
          gradeArr: arr
        })
      }
    }
  },

  ready() {
  },

  /**
   * 组件的初始数据
   */
  data: {
    name: '',
    tel: '',
    grade: '',
    subject: '',
    gradeIndex: '',
    subjecgtIndex: '',
    gradeArr: [],
    subjectArr: [],
    isSelectSubject: true,
    code:'',
    validateCodeText:'验证码',
    sended:false
  },
  attached() {
  },
  /**
   * 组件的方法列表
   */
  
  methods: {
    formateData2Arr(obj) {
      let arr = []
      for(let key in obj) {
        arr.push({
          id: key,
          title: obj[key].title || obj[key],
          subject: obj[key].subject || null
        })
      }
      return arr
    },
    pickerChange(e) {
      const type = e.currentTarget.dataset.type
      switch (type) {
        case 'grade':
          const subjectArr = this.formateData2Arr(this.data.gradeArr[e.detail.value].subject)
          this.setData({
            gradeIndex: e.detail.value,
            subjectArr: subjectArr,
            subjecgtIndex: '',
            isSelectSubject: false
          })
          return;
        case 'subject':
          this.setData({
            subjecgtIndex: e.detail.value
          })
          return;
      }
    },
    showToast(title, icon = "none") {
      wx.showToast({
        title,
        icon
      })
    },
    checkParams(params) {
      if(!params.true_name) {
        this.showToast('名字不能为空！')
        return false
      }
      if(!params.telephone) {
        this.showToast('手机号不能为空！')
        return false
      }
      if(!/^1[3456789]\d{9}$/.test(params.telephone)) {
        this.showToast('手机号格式不正确！')
        return false
      }
      if(!params.grade) {
        this.showToast('年级不能为空！')
        return false
      }
      return true
    },
    checkCode(e) {
      if(!this.data.isBoost){
        app.aldstat.sendEvent('线索填写页-“立即领取”按钮点击',{
          open_id: app.getOpenId(),
          book_id: this.data.item.book_id
        })
      } else {
        app.aldstat.sendEvent('助力人线索填写页-“立即领取”按钮点击',{
          open_id: app.getOpenId(),
          book_id: this.data.item.book_id
        })
      }
      
      if(this.data.code === ''){
        this.showToast('请输入验证码')
        return
      }
      checkValidateCode({data:{telephone:this.data.tel,validationCode:this.data.code}}).then(({data})=>{
        if(!data.success) {
          this.showToast('验证码不正确')
        }else {
          this.formSubmit(e)
        }
      })
    },
    formSubmit(e) {
      let params = e.detail.value
      const _this = this
      console.log('form', e)
      sendFormId({data: {form_id: e.detail.formId}})
      if(this.checkParams(params)) {
        let item = this.data.item
        let obj = {
          bookId: item.book_id,
          source: 'NW_家长端_小程序_精选资料库'
        }
        console.log('this.data.isBoost outeert', this.data.isBoost)
        if(this.data.isBoost && app.globalData.powerId){
          let userInfo = app.globalData.userInfo
          let powerId = app.globalData.powerId
          obj['powers_id'] = powerId
          obj['avatar'] = userInfo && userInfo.avatarUrl
          obj['nick_name'] = userInfo && userInfo.nickName
          console.log('app.globalData.powerId innnerr----', app.globalData.powerId)
          console.log('app.globalData.userInfo innnerr----', app.globalData.userInfo)
        }
        params = Object.assign({}, params, obj)
        console.log('isboost', this.data.isBoost)
        console.log('submitform params', params)
        submitForm({
          data: params,
          boost: this.data.isBoost
        })
        .then(res => {
          const data = res.data
          console.log('submitform then', data)
          let detail = {
              itemId: item.book_id,
              boost: this.data.isBoost
            }
          detail['isHidden'] = true
          if(data.success) {
            // detail['isHidden'] = true
            // _this.showToast(_this.data.tip)
            _this.triggerEvent('formSubmit', detail)
          } else{
            _this.showToast(data.msg || '')
          }
        })
        .catch(err => {
          _this.showToast('请求错误！')
        })
      }
    },
    hideModal(){
      this.triggerEvent('close-mask')
    },
    bindKeyInput:function(e) {
      let field = e.target.dataset.type
      this.setData({
        [field]: e.detail.value
      })
    },
    countDown(){
      let countDown = 60
      this.setData({
        sended:true
      })
      this.setCountDownTime(countDown)
      const timer = setInterval(()=>{
        this.setCountDownTime(countDown)
        if(countDown === 0) {
          clearInterval(timer)
          this.setData({
            validateCodeText:'验证码',
            sended:false
          })
        }
        countDown--
      },1000)
    },
    setCountDownTime(countDown){
      this.setData({
        validateCodeText: countDown + 's',
      })
    },
    getValidateCode() {
      if(this.data.validateCodeText !== '验证码'){
        return
      }
      if(this.data.tel === '') {
        this.showToast('手机号不能为空！')
        return
      }
      if(!/^1[3456789]\d{9}$/.test(this.data.tel)) {
        this.showToast('手机号格式不正确！')
        return false
      }
      sendValidateCode({data:{telephone:this.data.tel}}).then(({data})=>{
        if(data.success) {
          this.showToast('已发送')
          this.countDown()
          console.log('验证码',data)
        }
      })
    }
  }
})
