
// 请求基链接
// const baseUrl = 'https://1v1-activity.xueba100.com';
const baseUrl = 'http://qa02-activity.xuebadev.com';
// const baseUrl = 'http://activity-qa.xuebadev.com';

export function wxRequest(url, params) {
  let data = ''
  // 不传参数，或者
  const openId = wx.getStorageSync('openId')
  const activityId = 148
  if(!params) {
    data = {
      'openId': openId,
      "activityId": activityId
    }
  } else if (params.authorize) {
    data = params.data
  } else if(params.data && !params.authorize){
    data = Object.assign({}, params.data, {
      'openId': openId,
      "activityId": activityId
    })
  }

  return new Promise((resolve, reject) => {
    wx.request({
      url: `${baseUrl}${url}`,
      method: (params && params.method) || 'POST',
      data: data,
      header: (params && params.header) || {'content-type': 'application/json'},
      success(res) {
        resolve(res)
      },
      fail(err) {
        reject(err)
      },
      complete() {
        params && params.complete && params.complete()
      }
    })
  })
}

export function sendCode(params) {
  return wxRequest('/dzhk/code', params)
}

// 获取电子资料介绍
export function getElectronicInfo(params) {
  return wxRequest('/dzhk/getBase', params)
}
// 获取电子资料列表
export function getElectronicDataList(params) {
  return wxRequest('/dzhk/getBookLists', params)
}
//获取年级学科
export function getGradeSubject(params) {
  return wxRequest('/dzhk/getGradeSubject')
  // return wxRequest('/inRoade/parse', params)
}
//提交线索表单
export function submitForm(params) {
  if(params.boost) {
    console.log('/dzhk/bargain')
    return wxRequest('/dzhk/bargain', params)
  } else {
    console.log('/dzhk/singUp')
    return wxRequest('/dzhk/singUp', params)
  }
}

export function sendFormId(params) {
  return wxRequest('/dzhk/saveFormId', params)
}

// 已获取线索，只想解锁当前书籍
export function unlockBook(params) {
  return wxRequest('/dzhk/toReceive', params)
}
//获取detail
export function getDetail(params) {
  return wxRequest('/dzhk/getBookInfo', params)
}

// 发起助力
export function startBoost(params) {
  return wxRequest('/dzhk/joins', params)
}
// 更新时间戳
export function updateTimestamp(params) {
  return wxRequest('/dzhk/upPower', params)
}

//直接助力
export function bargain(params) {
  return wxRequest('/dzhk/bargain', params)
}

// 轮询助力成功与否
export function askBoostStatus(params) {
  return wxRequest('/dzhk/getPowers', params)
}

//  新线索发送验证码
export const sendValidateCode = function(params) {
  return wxRequest('/sweepstakes/sendValidationCode', params)
}
//  新线索校验验证码
export const checkValidateCode = function(params) {
  return wxRequest('/sweepstakes/checkValidationCode', params)
}
//  修改状态为下载完成
export const download = function(params) {
  return wxRequest('/dzhk/upPower', params)
}