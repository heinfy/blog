const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}
/*获取当前页带参数的url*/
function getCurrentPageUrl(){
  var pages = getCurrentPages()    //获取加载的页面
  var currentPage = pages[pages.length-1]    //获取当前页面的对象
  var url = currentPage.route    //当前页面url
  var options = currentPage.options    //如果要获取url中所带的参数可以查看options
  
  //拼接url的参数
  var urlWithArgs = url 
  if(Object.keys(options).length) {
    urlWithArgs += '?'
    for(var key in options){
        var value = options[key]
        urlWithArgs += key + '=' + value + '&'
    }
    urlWithArgs = urlWithArgs.substring(0, urlWithArgs.length-1)
  }
  
  return urlWithArgs
}

const getAddexpired = (end, expired) => {
  let time = new Date(end)
  // expired小时制
  time = time.setTime(time.getTime() + expired * 60 * 60 * 1000)
  return new Date(time).getTime();
}

const countDownFun = ({endtime, timerobj, callback}) => {
  console.log('end timestamp', endtime, new Date(endtime))
  let end = new Date(endtime).getTime()
  console.log('end end', end)
  let now = new Date().getTime()
  // let timer = null
  if(now < end) {
    timerobj.timer = setInterval(() => {
      now = new Date().getTime()
      console.log('end: ', new Date(end), 'now: ', new Date(now))
      let remain = parseInt((end - now) / 1000)
      // console.log('remain', (end - now))
      let days = parseInt(remain / (24 * 60 * 60))
      // let hours = parseInt(remain % (24 * 60 * 60) / 3600)
      // let minutes = parseInt(remain % (24 * 60 * 60) % 3600 / 60)
      // let seconds = parseInt(remain % (24 * 60 * 60) % 3600 % 60)
      let hours = parseInt(remain / (60 * 60))
      // console.log('hours', hours)
      let minutes = parseInt(remain % ( 60 * 60) / 60)
      let seconds = parseInt(remain % ( 60 * 60) % 60)

      // console.log(days,'天',hours,':',minutes,':',seconds)
      const obj = {
        // timer: timer,
        days: prefixData(days),
        hours: prefixData(hours),
        minutes: prefixData(minutes),
        seconds: prefixData(seconds)
      }
      callback(obj)
    }, 1000)
  } else {
    clearInterval(timerobj.timer)
    const obj = {
      days: '00',
      hours: '00',
      minutes: '00',
      seconds: '00'
    }
    callback(obj)
  }
}

const prefixData = (data) => {
  return data > 10 ? data : '0' + data
}

module.exports = {
  formatTime: formatTime,
  getAddexpired: getAddexpired,
  countDownFun: countDownFun,
  getCurrentPageUrl: getCurrentPageUrl
}
