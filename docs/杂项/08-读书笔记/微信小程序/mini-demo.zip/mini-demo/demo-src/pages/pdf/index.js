Page({
  data:{
    pdfUrl:''
  },
  onLoad(options) {
    this.setData({
      pdfUrl:options.pdfUrl
    })
  }
})
