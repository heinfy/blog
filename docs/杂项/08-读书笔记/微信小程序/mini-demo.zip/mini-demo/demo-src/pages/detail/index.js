// src/pages/detail/index.js
import {getCurrentPageUrl} from '../../utils/util'
import {download,getDetail, getGradeSubject, bargain, startBoost, unlockBook, sendFormId, askBoostStatus} from '../../api/index'
let app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    detailId: '',
    detail: {},
    tempFilePath: '',
    savePath: '',
    hasUserInfo: false,
    userInfo: '',
    isBoostUser: false,
    boostSuccess: false,
    stage: '',
    currentDownloadCount: '',
    downloadBtn: false,
    gradeData: null,
    boostData: null,
    showBoost: false,
    loading: true,
    downloadDialog:true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    app.aldstat.sendEvent('助力详情页面曝光',{
      open_id: app.getOpenId(),
      book_id: options.id
    })
    wx.showLoading({
      title: '加载中',
    })
    if(app.getOpenId()) {
      this.inOnLoadRequest(options)
    } else{
      app.login()
      .then(res => {
        this.inOnLoadRequest(options)
      })
    }
    
    if(app.getStrogeUserInfo()) {
      this.setUserInfo({hasUserInfo: true, userInfo: app.getStrogeUserInfo()})
    }
  },
  inOnLoadRequest(options) {
    const {id, stage} = options
    this.setData({
      detailId: id,
      stage: stage
    })
    console.log('options:', options)

    // 获取年龄数据
    getGradeSubject()
    .then(res => {
      let  data = res.data
      if(data.success) {
        data = data.data
        this.setData({
          gradeData: data
        })
      }
    })
    app.globalData.powerId = options.powerId
    this._getDetail(options)
  },
  _getDetail(options) {
    let obj = { 
        bookId: options.id,
        stage: Number(options.stage),
        powers_id:Number(app.globalData.powerId)
      }
    getDetail({
      data: obj
    }).then(res => {
      let data = res.data;
      if(data.success) {
        data = data.data
        this.setData({
          detail: data
        })
        if(data.powers_id !== 0) {
          app.globalData.powerId = data.powers_id
        }
        console.log('detail',data)
        if(data.is_self && data.type !=3 ) {
          this.pollingBoostStatus()
        }
        this.setData({
          currentDownloadCount: this.getHistroyDownload()
        })
      }else {
        wx.showToast({
          title: data.msg,
          icon: 'none'
        })
      }

      if(this.data.loading) {
        wx.hideLoading()
        this.setData({
          loading: false
        })
      }
      console.log('detail data', data)
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    console.log('onHide')
    // this.clearIntervalTimer()
    // this.clearPollingBoostTimer()
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    console.log('onUnload')
    this.clearIntervalTimer()
    this.clearPollingBoostTimer()
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    const boost = this.selectComponent('#boost')
    const detailId = +this.data.detailId
    console.log('share boost.data', boost.data)
    boost.setData({
      showAvatars: true,
    })
    let url = `/pages/invite/index?id=${detailId}&stage=${this.data.stage}&powerId=${app.globalData.powerId}&avatars=${encodeURIComponent(this.data.userInfo.avatarUrl)}`
    console.log('url',url)
    return {
      title: '免费领「2020开学必备高分笔记」，抢跑新学期！',
      path: url,
      imageUrl: 'https://wenba-ooo-qiniu.xueba100.com/1c53dc1d748f1e32131b40793c4ff3db.png'
    }
  },
  _startBoost() {
    const userInfo = app.globalData.userInfo
    const nickName = userInfo.nickName
    const avatarUrl = userInfo.avatarUrl
    const params = {
      data: {
        nick_name: nickName,
        avatar_url: avatarUrl,
        bookId: this.data.detailId
      }
    }
    // 注册助力id
    return new Promise((resolve, reject) => {
      startBoost(params)
      .then(res => {
        const data = res.data;
        if(data.success) {
          console.log('joins data: ', data)
          app.globalData.powerId = data.data.powers_id
          this.setData({
            boostData: data.data
          })
          resolve(data.data)
        } else {
          wx.showToast({
            title: data.msg,
            icon: 'none'
          })
        }
      })
      .catch(err => {
        reject(err)
        wx.showToast({
          title: '邀请助力请求接口失败！',
          icon: 'none'
        })
      })
    })
  },
  _getUserInfo(e) {
    // 只有在open-type是获取用户信息时才触发该方法，若不是获取用户信息类型的按钮则无法触发，会导致powerId为注册
    const userInfo = e.detail.userInfo
    if(userInfo) {
      this.setUserInfo({hasUserInfo: true, userInfo})
      wx.setStorageSync('userInfo', userInfo)
    } else {
      this.setUserInfo({hasUserInfo: false, userInfo: ''})
    }
    console.log('_getUserInfo', userInfo)
  },
  judgeJoined() {
    this._startBoost()
    .then(res => {
      // this.showBoostDialog()
    })
  },
  clearIntervalTimer() {
    clearInterval(app.globalData.timer)
    let boostData = this.data.boostData
    if(boostData) {
      boostData.dateline = 0;
      this.setData({
        boostData: boostData
      })
    }
  },
  waitJoinedShowBoost() {
    // status=1;已领取未助力
    if(this.data.detail.status === 1){
      this.judgeJoined()
    }
    app.aldstat.sendEvent('助力详情页-“立即邀请”按钮点击',{
      open_id: app.getOpenId(),
      book_id: this.data.detailId
    })
    wx.requestSubscribeMessage({
      tmplIds:['YsPYUAmjOURjF7SHS-uhtBtbQoEIBp8lfgVNwvwjH2Q',
      '43vvHfSefmsvzODTBmcJ33OW-bkjPmV0qFnexJR9OUE']
    })
  },
  setUserInfo({hasUserInfo, userInfo}) {
    app.globalData.hasUserInfo = false
    app.globalData.userInfo = userInfo
    this.setData({
      userInfo,
      hasUserInfo
    })
  },
  formIdSubmit(e) {
    sendFormId({data: {form_id: e.detail.formId}})
    .then(res => {
      const data = res.data
      if(data.success) {
        console.log('formId收集成功!')
      } else {
        console.log('formId收集失败!')
      }
    })
    .catch(err => {
      console.log('formId收集失败!')
    })
  },
  pollingBoostStatus() {
    const powerId = app.globalData.powerId
    if(powerId) {
      let timer = setInterval(() => {
        askBoostStatus({data: {powers_id: powerId}})
        .then(res => {
          const data = res.data
          if(data.success) {
            let detail = this.data.detail
            detail.type = data.data.type
            if(detail.type) {
              this.setData({
                detail: detail
              })
            }
            if(detail.type == 3) {
              this.clearPollingBoostTimer()
            }
            console.log('detail.type', detail.type)
          }
        })
      }, 10000);
      this.setData({
        pollingBoostTimer: timer
      })
    }
  },
  clearPollingBoostTimer() {
    if(this.data.pollingBoostTimer) {
      clearInterval(this.data.pollingBoostTimer)
    }
  },
  setFormDialogStatus({hidden, el='#form-dialog'}) {
    let childDialog = this.selectComponent(el)
    childDialog && childDialog.setData({
      isHidden: hidden
    })
  },
  handlePdf() {
    const savePath = this.data.savePath
    if(savePath) {
      this.handleOpenDocument(savePath)
    } else {
      this.handleDownloadFile()
      .then(file => {
        this.handleOpenDocument(file)
      })
    }
  },
  handleOpenDocument(tempFilePath) {
    wx.openDocument({
      filePath: tempFilePath,
      success: (result)=>{
        console.log('pdf打开成功')
      },
      fail: (err)=>{
        wx.showToast({
          title: `pdf打开失败${err.errMsg}`,
          icon: 'none'
        })
      }
    });
  },
  saveDocumentToLocal(e) {
    this.setData({
      downloadBtn: true
    })
    this.setFormDialogStatus({hidden: false, el: '#download-url-dialog'})
    this.updateHistroyDownload()
  },
  clearSaveFileList() {
    wx.getSavedFileList({
      success (res) {
        console.log('wx.getSavedFileList',res)
        if (res.fileList.length > 0){
          wx.removeSavedFile({
            filePath: res.fileList[0].filePath,
            complete (res) {
              console.log(res)
            }
          })
        }
      },
      fail(err) {
        console.log('wx.getSavedFileList fail')
        wx.showToast({
          title: err.errMsg,
          icon: 'none'
        })
      }
     })
  },
  handleDownloadFile(){
    // const url = 'http://10.192.41.52:8899/pdfdemo/vue-ssr.pdf'
    const url = this.data.detail.pdfUrl
    return new Promise((resovle, reject) => {
      wx.downloadFile({
        url: url,
        success: (result)=>{
          console.log('wx.downloadFile', result)
          console.log('fs fs wx.env', wx.env.USER_DATA_PATH)
          resovle(result.tempFilePath)
        },
        fail: (err)=>{
          wx.showToast({
            title: err.errMsg,
            icon: 'none'
          })
          reject(err)
        }
      });
    })
  },
  fsSaveFile(file) {
    const fs = wx.getFileSystemManager()
    const _this = this
    fs.saveFile({
      tempFilePath: file,
      success: (result)=>{
          console.log('fs.saveFile success', result)
          const dir = `${wx.env.USER_DATA_PATH}/pdfs`
          const savedFilePath = result.savedFilePath
          fs.readdir({
            dirPath: dir,
            success: (res) => {
              // 如果目录存在则直接复制
              _this.fsCopyFile(savedFilePath, dir)
            },
            fail: (err) => {
              //如果目录不存在则创建目录后复制文件
              fs.mkdir({
                dirPath: dir,
                success: (res) => {
                  console.log('fs.mkdir success', res)
                  _this.fsCopyFile(savedFilePath, dir)
                },
                fail: (err) => {
                  console.log('fs.mkdir fail', err)
                  wx.showToast({
                    title: err.errMsg,
                    icon: 'none'
                  })
                }
              })
            }
          })
      },
      fail: (err)=>{
        console.log('保存文件fail')
        wx.showToast({
          title: err.errMsg,
          icon: 'none'
        })
      }
    })
  },
  fsCopyFile(savedFilePath, dir) {
    const filename = (this.data.detail && this.data.detail.title || '未知文件名') + '.pdf'
    const fs = wx.getFileSystemManager()
    const dtDir =  `${dir}/${filename}`
    const _this = this
    fs.copyFile({
      srcPath: savedFilePath,
      destPath: dtDir,
      success: (res) => {
        console.log('copyFile success', dtDir)
        wx.showToast({
          title: `${filename}下载成功`,
          icon: 'none'
        })
        this.handleOpenDocument(dtDir)
        this.updateHistroyDownload()
        _this.setData({
          savePath: dtDir,
          currentDownloadCount: _this.getHistroyDownload()
        })
        console.log('currentDownloadCount', this.data.currentDownloadCount)
      },
      fail: (err) => {
        console.log('copyFile fail', err)
        wx.showToast({
          title: err.errMsg,
          icon: 'none'
        })
      }
    })
  },
  setKey() {
    return `${app.getOpenId()}.${this.data.stage}.${this.data.detail.book_id}`
  },
  getHistroyDownload() {
    return wx.getStorageSync(this.setKey())
  },
  updateHistroyDownload() {
    const key = this.setKey()
    let value = this.getHistroyDownload()
    if(value) {
      wx.setStorageSync(key, ++value)
    } else{
      wx.setStorageSync(key, 1)
    }
    this.setData({
      currentDownloadCount: this.getHistroyDownload()
    })
  },
  showDownloadDialog(){
    app.aldstat.sendEvent('助力详情页-“立即下载“按钮点击',{
      open_id: app.getOpenId(),
      book_id: this.data.detailId
    })
    this.setFormDialogStatus({hidden: false, el: '#download-url-dialog'})
    app.aldstat.sendEvent('获取下载连接弹窗曝光',{
      open_id: app.getOpenId(),
      book_id: this.data.detailId
    })
  },
  download() {
    app.aldstat.sendEvent('获取下载连接弹窗内部“点击领取”按钮点击',{
      open_id: app.getOpenId(),
      book_id: this.data.detailId
    })
    let params =  {
      power_id:app.globalData.powerId
    }
    download({data:params}).then(({data})=>{
      if(!data.success){
        wx.showToast({
          title: data.msg,
          icon: 'none'
        })
      }
    })
  },
  goMoreBook(){
    app.aldstat.sendEvent('助力详情页-“查看全部“按钮点击',{
      open_id: app.getOpenId(),
      book_id: this.data.detailId
    })
    wx.navigateTo({url:'/pages/index/index'})
  },
  goPdf(e) {
    app.aldstat.sendEvent('助力详情页-“查看全部“按钮点击',{
      open_id: app.getOpenId(),
      book_id: this.data.detailId
    })
    let systemInfo = wx.getSystemInfoSync()
    console.log(e)
    let pdfUrl = e.target.dataset.pdf
    if (~systemInfo.system.indexOf('iOS')) {
      wx.navigateTo({ url: `/pages/pdf/index?pdfUrl=${pdfUrl}` })
      return
    }
    wx.downloadFile({
      url: pdfUrl, //要预览的PDF的地址
      success: function(res) {
        console.log(res)
        if (res.statusCode === 200) {
          //成功
          var Path = res.tempFilePath //返回的文件临时地址，用于后面打开本地预览所用
          wx.openDocument({
            filePath: Path, //要打开的文件路径
            success: function(res) {
              console.log('打开PDF成功')
            }
          })
        }
      },
      fail: function(res) {
        console.log(res) //失败
      }
    })
  }
})