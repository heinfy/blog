//index.js
import {
  getElectronicInfo,
  getElectronicDataList,
  getGradeSubject,
  unlockBook,
  sendFormId
} from '../../api/index.js'
//获取应用实例
const app = getApp()

Page({
  data: {
    introInfo: {},
    lists: [],
    curItem: '',
    userInfo: {},
    btnText: '免费领取',
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    curTab: 0,
    listsHigh: [],
    swiperHeights: [0, 0],
    isJoin: 0,
    gradeData: null,
    isTapTab: false,
    bookType:[[]],//tab页数据
    currentBookListLength:0,
    stage:2,
    phaseList:[],
    currentPhase:0 // 当前选中小初高，默认全部
  },
  onLoad: function() {
    app.globalData.swiperHeights = [0, 0]
    this._loadisOpenId(this.inOnLoadRequest)
  },
  onShow() {
    app.aldstat.sendEvent('学霸君资料库主页曝光',{
      open_id: app.getOpenId()
    })
    this.setData({
      isTapTab: false
    })
    this._loadisOpenId(() => {
      this.getLists(this.data.curTab,this.data.stage)
    })
  },
  _loadisOpenId(fn) {
    if (app.getOpenId()) {
      console.log('has getOpenId')
      fn()
    } else {
      console.log('no getOpenId')
      app.login().then(res => {
        fn()
      })
    }
  },
  inOnLoadRequest() {
    getElectronicInfo().then(res => {
      const data = res.data
      if (data.success) {
        let bookType = []
        data.data.classify.forEach(element => {
          bookType.push([])
        });
        this.setData({
          introInfo: data.data,
          bookType:bookType,
          phaseList:data.data.phaseList
        })
      }
    })
    // 获取年龄数据
    getGradeSubject().then(res => {
      let data = res.data
      if (data.success) {
        data = data.data
        this.setData({
          gradeData: data
        })
      }
    })
  },
  getLists(type = 0,stage = 2) {

    wx.showLoading({
      title: '加载中'
    })
    getElectronicDataList({ data: { stage: stage , phase:Number(this.data.currentPhase)} }).then(
      res => {
        console.log(res)
        const data = res.data
        if (data.success) {
          let bookType = this.data.bookType
          bookType[type] = data.data.lists.sort((a,b)=>{
            if(a.status < b.status){
              return -1
            }
          })
          console.log(bookType)
          console.log(data.data.lists)

          this.setData({
            currentBookListLength:data.data.lists.length,
            bookType:bookType,
            isJoin:data.data.is_join
          })
          wx.hideLoading()
        }
      }
    )
  },
  getUserInfo: function(e) {
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  handleFormSubmit(e,i) {
    console.log(e,i)
    const curId = e.detail.itemId
    const curTab = this.data.curTab
    // this.setMapListStatus(curId, curTab)
    this.setFormDialogStatus({ hidden: true })
    this.setFormDialogStatus({el:'#success-dialog', hidden: false })
    this.clearBookType().then(()=>{
      this.getLists(this.data.curTab,this.data.stage)
    })
    app.aldstat.sendEvent('线索填写页-领取成功弹窗曝光',{
      open_id: app.getOpenId(),
      book_id: this.data.curItem.book_id
    })
  },
  setFormDialogStatus({ el = '#form-dialog', hidden }) {
    let childDialog = this.selectComponent(el)
    childDialog.setData({
      isHidden: hidden
    })
  },
  changePhase(e){
    const phase = e.currentTarget.dataset.phase
    this.setData({
      currentPhase:phase
    })
    this.getLists(this.data.curTab,this.data.stage)
  },
  changeStage(e) {
    const currentIndex = e.currentTarget.dataset.current
    const stage = e.currentTarget.dataset.stage
    this.setData({
      curTab: currentIndex,
      stage:stage,
      currentBookListLength:this.data.bookType[currentIndex].length,
      currentPhase:0
    })
    this.setData({
      isTapTab: true
    })
    console.log(currentIndex)
    let event = this.data.introInfo.classify[currentIndex].name
    app.aldstat.sendEvent('主页-tab位'+event+'点击',{
      open_id: app.getOpenId()
    })
    this.getLists(currentIndex,stage)
  },
  formIdSubmit(e) {
    sendFormId({ data: { form_id: e.detail.formId } })
      .then(res => {
        const data = res.data
        if (data.success) {
          console.log('formId收集成功!')
        } else {
          console.log('formId收集失败!')
        }
      })
      .catch(err => {
        console.log('formId收集失败!')
      })
  },
  changeSwiper(e) {
    const source = e.detail.source
    const current = e.detail.current
    if (source == 'touch') {
      const stage = this.data.introInfo.classify[current].id
      this.setData({
        curTab: current,
        stage:stage,
        currentBookListLength:this.data.bookType[current].length, 
      })
      this.setData({
        isTapTab: true
      })
      this.getLists(current,stage)
    }
  },
  goDetail(e) {
    this.setData({
      curItem: e.currentTarget.dataset.item
    })
    switch (this.data.curItem.status) {
      case 0:
          app.aldstat.sendEvent('主页-资料“领取”点击',{
            open_id: app.getOpenId()
          })
          break
      case 1:
          app.aldstat.sendEvent('主页-资料“助力”点击',{
            open_id: app.getOpenId()
          })
          break
      case 2:
          app.aldstat.sendEvent('主页-资料“助力”点击',{
            open_id: app.getOpenId()
          })
          break
      case 3:
          app.aldstat.sendEvent('主页-资料“下载”点击',{
            open_id: app.getOpenId()
          })
          break            
    }
    
    if (this.data.isJoin === 1) {
      this.unlockBook(e.currentTarget.dataset.item)
      this.clearBookType(500)
    } else {
      this.setFormDialogStatus({ hidden: false })
      app.aldstat.sendEvent('线索填写页面曝光',{
        open_id: app.getOpenId(),
        book_id: this.data.curItem.book_id
      })
    }
  },
  //为了刷新列表数据,清除列表数据
  clearBookType(time = 0){
    return new Promise((resolve,reject)=>{
      setTimeout(()=>{
        let bookType = []
        this.data.bookType.forEach(element => {
          bookType.push([])
        });
        this.setData({
          bookType:bookType
        })
        resolve()
      },time)
    }) 
  },
  seeMybook(){
    app.aldstat.sendEvent('线索填写页-领取弹窗内“查看我的资料”点击',{
      open_id: app.getOpenId(),
      book_id: this.data.curItem.book_id
    })
    wx.navigateTo({
      url: `/pages/detail/index?id=${this.data.curItem.book_id}&powerId=${this.data.curItem.power_id}&stage=${this.data.stage}`
    })
  },
  unlockBook(item){
    unlockBook({ data: { bookId: item.book_id } })
        .then(res => {
          // if(res.data.success) {
          //   app.globalData.powerId = res.data.data.powers_id
          // }

          // let powerId = this.data.curItem.power_id === 0  ? app.globalData.powerId : this.data.curItem.power_id
          wx.navigateTo({
            url: `/pages/detail/index?id=${this.data.curItem.book_id}&powerId=${this.data.curItem.power_id}&stage=${this.data.stage}`
          })
        })
        .catch(err => {
          wx.showToast({
            title: '领取失败',
            icon: 'none'
          })
        })
  }
})
