import {getDetail,submitForm,getGradeSubject} from '../../api/index'
let app = getApp();

Page({
  data:{
    userInfo:app.getStrogeUserInfo(),
    avatars:'',
    hasUserInfo:app.getStrogeUserInfo() === '' ? false : true,
    gradeData:null,
    book_id:'',
    stage:2,
    detail:{}
  },
  onLoad(options) {
    app.aldstat.sendEvent('助力人助力页面曝光',{
      open_id: app.getOpenId(),
      book_id: options.id
    })
    console.log('options',options)
    wx.showLoading({
      title: '加载中',
    })
    console.log('options',options)
    this.setData({
      avatars:decodeURIComponent(options.avatars),
      powers_id:options.powerId,
      book_id:options.id,
      stage:options.stage
    })
    app.globalData.powerId = options.powerId
    if(this.data.hasUserInfo){
      app.globalData.userInfo = this.data.userInfo
    }
    getGradeSubject()
    .then(res => {
      let  data = res.data
      if(data.success) {
        data = data.data
        this.setData({
          gradeData: data
        })
      }
    })
    if(app.getOpenId()) {
      this.getBookDetail(options)
    } else{
      app.login()
      .then(res => {
        this.getBookDetail(options)
      })
    }
    
  },
  getBookDetail(options){
    let obj = { 
      bookId: options.id,
      stage: Number(options.stage),
      powers_id:Number(options.powerId)
    }
    getDetail({data: obj}).then(res => {
      let data = res.data;
      if(data.success) {
        data = data.data
        console.log('detail',data)
        this.setData({
          detail: data
        })
        wx.hideLoading()
        this.isSelfJump(data)

      }
    })
  },
  isSelfJump(detail){
    if(detail.is_self === 1){
      wx.showToast({
        title: '不能给自己助力',
        icon: 'none'
      })
      setTimeout(()=>{
        wx.navigateTo({url:`/pages/detail/index?id=${detail.book_id}&stage=${this.data.stage}&powerId=${app.globalData.powerId}`})
      },1000)
    }
  },
  isJoinJump (detail) {
    wx.showToast({
      title: '您已领取过资料，不能参与助力!',
      icon: 'none'
    })
    setTimeout(()=>{
      wx.navigateTo({url:`/pages/index/index`})
    },1000)
    
  },
  showClueDialog() {
    app.aldstat.sendEvent('助力人“为ta助力”按钮点击',{
      open_id: app.getOpenId(),
      book_id: this.data.book_id
    })
    if(this.data.detail.is_self === 1){
      this.isSelfJump(this.data.detail)
      return
    }
    if(this.data.detail.is_join === 1){
      this.isJoinJump(this.data.detail)
      return
    }
    this.setFormDialogStatus({hidden:false})
    app.aldstat.sendEvent('助力人线索填写页面曝光',{
      open_id: app.getOpenId(),
      book_id: this.data.book_id
    })
  },
  setFormDialogStatus({ el = '#form-dialog', hidden }) {
    let childDialog = this.selectComponent(el)
    childDialog.setData({
      isHidden: hidden
    })
  },
  _getUserInfo(e) {
    // 只有在open-type是获取用户信息时才触发该方法，若不是获取用户信息类型的按钮则无法触发，会导致powerId为注册
    const userInfo = e.detail.userInfo
    if(userInfo) {
      this.setUserInfo({hasUserInfo: true, userInfo})
      wx.setStorageSync('userInfo', userInfo)
    } else {
      this.setUserInfo({hasUserInfo: false, userInfo: ''})
    }
    console.log('_getUserInfo', userInfo)
  },
  setUserInfo({hasUserInfo, userInfo}) {
    app.globalData.hasUserInfo = hasUserInfo
    app.globalData.userInfo = userInfo
    this.setData({
      userInfo,
      hasUserInfo
    })
  },
  handleFormSubmit(e){
    console.log('e',e)
    this.setFormDialogStatus({hidden:true})
    this.setFormDialogStatus({hidden:false,el:'#success-dialog'})
    app.aldstat.sendEvent('助力人线索填写页-领取成功弹窗曝光',{
      open_id: app.getOpenId(),
      book_id: this.data.book_id
    })
  },
  seeMyBook(){
    app.aldstat.sendEvent('助力人线索填写页-领取成功弹窗内“查看我的资料”点击',{
      open_id: app.getOpenId(),
      book_id: this.data.book_id
    })
    wx.navigateTo({
      url: `/pages/detail/index?id=${this.data.book_id}&stage=${this.data.stage}&powerId=0`
    })
  },
  formIdSubmit(e) {
    sendFormId({ data: { form_id: e.detail.formId } })
      .then(res => {
        const data = res.data
        if (data.success) {
          console.log('formId收集成功!')
        } else {
          console.log('formId收集失败!')
        }
      })
      .catch(err => {
        console.log('formId收集失败!')
      })
  },
})