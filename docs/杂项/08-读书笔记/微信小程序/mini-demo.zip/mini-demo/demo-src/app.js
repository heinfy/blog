//app.js
import {sendCode} from 'api/index.js'
const ald = require('./utils/ald-stat.js')
App({
  onLaunch: function () {
    const _this = this
    wx.checkSession({
      success () {
        console.log('session_key 未过期')
      },
      fail () {
        console.log('session_key 已经失效')
        // _this.login() //重新登录
      }
    })
    // _this.login();
    // if(!wx.getStorageSync('openId')) {
    //   this.login()
    // }
  },
  getOpenId() {
    return wx.getStorageSync('openId')
  },
  getStrogeUserInfo() {
    return wx.getStorageSync('userInfo')
  },
  login: function() {
    return new Promise((resolve, reject) => {
      wx.login({
        success: res => {
          console.log('res', res)
          const params = {
            authorize: true,
            data: {
              code: res.code
            }
          }
          console.log('sendcode 222', params)
          sendCode(params)
            .then(res => {
              const data = res.data;
              if (data.success) {
                const openId = data.data && data.data.openid
                wx.setStorageSync('openId', openId)
              } else {
                wx.showToast({
                  title: '获取openid失败！',
                  icon: 'none'
                })
              }
              resolve(data)
            })
            .catch(err => {
              wx.showToast({
                title: '获取openid接口失败',
                icon: 'none'
              })
              reject(err)
            })
        },
        fail: () => {
          wx.showToast({
            title: '登陆失败'
          })
        }
      })
    })
  },
  getUserInfo: function() {
    const _this = this
    return new Promise((resolve, reject) => {
      wx.getUserInfo({
        success: (res) => {
          this.globalData.userInfo = res.userInfo
          wx.setStorageSync('userInfo', res.userInfo)
          console.log('getUserInfo: ', res)
          resolve(res)
        },
        fail: (err) => {
          console.log('getUserInfo fail: ', err)
          reject(err)
        }
      })
    })
  },
  globalData: {
    userInfo: null
  }
})