const common = {
  BTN_SUBMIT_NAME: '确定',

  NO_LOGIN: '未登录',
}

export default common