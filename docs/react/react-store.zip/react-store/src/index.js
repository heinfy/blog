import React from 'react'
import ReactDOM from 'react-dom'
import { Provider } from 'react-redux'

import * as serviceWorker from './serviceWorker'

// ----------------- 01-react --------------------------------------
// import App from './01-react/App';
// ReactDOM.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>,
//   document.getElementById('root')
// )

// --------------- 02-redux ----------------------------------------
// import App from './02-redux/App'
// import store from './02-redux/redux/store'

// ReactDOM.render(
//   <React.StrictMode>
//     <App store={store} />
//   </React.StrictMode>,
//   document.getElementById('root')
// )

// store.subscribe(() => {
//   ReactDOM.render(
//     <React.StrictMode>
//       <App store={store} />
//     </React.StrictMode>,
//     document.getElementById('root')
//   )
// })

// --------------- 03-react-redux ----------------------------------------
// import App from './03-react-redux/App'
// import store from './03-react-redux/redux/store'

// ReactDOM.render(
//   <React.StrictMode>
//     <Provider store={store}>
//       <App />
//     </Provider>
//   </React.StrictMode>,
//   document.getElementById('root')
// )
  
// ------------------- 04-react-saga ------------------------------------
// import App from './04-react-saga/App'
// import store from './04-react-saga/store'

// ReactDOM.render(
//   <React.StrictMode>
//     <Provider store={store}>
//       <App />
//     </Provider>
//   </React.StrictMode>,
//   document.getElementById('root')
// )


// ----------------------- 05-react-thunk --------------------------------
import App from './05-react-thunk/App'
import store from './05-react-thunk/redux/store'

ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
)

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.register()
