import { takeEvery, select, call, put } from 'redux-saga/effects'

import axios from 'axios'

import { actions } from '../../constant'

export function* loginSaga() {
  yield takeEvery(actions.LOGIN, function* () {
    try {
      const state = yield select(state => state.user.data)
      const { data } = yield call(axios.post, '/api/login', state)
      console.log('获取值：', state, data)
      if(data.status === 1) {
        yield put({
          type: actions.SUCCESS_LOGIN,
          ...data
        })
      } else {
        yield put({
          type: actions.ERROR_LOGIN
        })
      }
    } catch (error) {
      yield put({
        type: actions.ERROR_LOGIN
      })
    }
  })
}
