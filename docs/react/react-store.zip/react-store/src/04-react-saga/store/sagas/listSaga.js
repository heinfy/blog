import { takeEvery, select, call, put } from 'redux-saga/effects'

import axios from 'axios'

import { actions } from '../../constant'

export function* listSaga() {
  yield takeEvery(actions.LIST, function* () {
    try {
      const state = yield select(state => state.list)
      const { data } = yield call(axios.post, '/api/login', state)
      console.log('获取list：', state, data)
      if(data.status === 1) {
        yield put({
          type: actions.SUCCESS_LIST,
          ...data
        })
      } else {
        yield put({
          type: actions.ERROR_LIST
        })
      }
    } catch (error) {
      yield put({
        type: actions.ERROR_LIST
      })
    }
  })
}
