import { actions } from '../../constant'

export function listReducer(state = {}, action) {
  switch (action.type) {
    case actions.LIST:
      return Object.assign({}, state, action)
    case actions.SUCCESS_LIST:
      // 进行获取list成功的操作，return 合适的值
      return action
    case actions.ERROR_LIST:
      // 进行获取list失败的操作，return 合适的值
      return action
    default:
      return state
  }
}
