import { actions } from '../../constant'

export function userReducer(state = {}, action) {
  switch (action.type) {
    case actions.LOGIN:
      return Object.assign({}, state, action)
    case actions.SUCCESS_LOGIN:
      // 进行登录成功的操作，return 合适的值
      console.log('SUCCESS_LOGIN action', action)
      return action
    case actions.ERROR_LOGIN:
      // 进行登录失败的操作，return 合适的值
      console.log('ERROR_LOGIN action', action)
      return action
    default:
      return state
  }
}
