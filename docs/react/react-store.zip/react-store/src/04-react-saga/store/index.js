
import { createStore, applyMiddleware, combineReducers } from 'redux'

import { userReducer } from './reducers/userReducer'
import { listReducer } from './reducers/listReducer'

// 导入saga，最终需要去run一下，执行一下 saga
import { defSaga } from './sagas'

import createSagaMiddleware from 'redux-saga'

// 构建 sagaMiddleware
const sagaMiddleware = createSagaMiddleware()

// createStore(defReducer, initState, middleware)
export default createStore(combineReducers({
  user: userReducer,
  list: listReducer
}), {}, applyMiddleware(sagaMiddleware))

sagaMiddleware.run(defSaga)
