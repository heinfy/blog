import { connect } from 'react-redux'
import { actions } from './constant'

import React, { Component } from 'react'

class LoginCom extends Component {
  login = () => {
    this.props.dispatch({
      type: actions.LOGIN,
      data: {
        username: 'admin',
        password: 'admin'
      }
    })
  }
  componentWillUpdate(newProps) {
    // 需要判断newProps, this.props
    console.log('newProps', newProps)
    console.log('this.props', this.props)
  }
  render() {
    return (
      <button onClick={this.login}>login</button>
    )
  }
}

const mapStateToProps = state => {
  return state.user
}
export default connect(mapStateToProps)(LoginCom)
