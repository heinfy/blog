import { connect } from 'react-redux'
import { actions } from './constant'

import React, { Component } from 'react'

class ListCom extends Component {
  componentDidMount() {
    this.props.dispatch({
      type: actions.LIST
    })
  }
  componentDidUpdate(oldProps) {
    // 需要判断newProps, this.props
    console.log('this.props', this.props)
  }
  render() {
    return (
      <button>这是list 组件</button>
    )
  }
}

const mapStateToProps = state => {
  return state.list
}
export default connect(mapStateToProps)(ListCom)
