import LoginCom from './LoginCom.jsx'
import ListCom from './ListCom.jsx'
import React, { Component } from 'react'

export default class App extends Component {
  render() {
    return (
      <div>
        <LoginCom></LoginCom>
        <br />
        <ListCom></ListCom>
      </div>
    )
  }
}
