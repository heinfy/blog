# redux-saga

[视频教程](https://www.bilibili.com/video/BV1aK411L7Ya)

## 1. redux-saga 介绍

### 1.1 中间件

中间件就是独立运行于各个框架之间的代码，本质就是一个函数，可访问请求和相应请求，可对请求进行拦截处理，处理够再将控制权向下传递，也可以终止请求，项客户端做出相应。

在 redux 中，middleware 是运行在 action 发送出去，到达 reducer 之间的一段代码，就可以把代码调用流程变成 action -> middleware -> reducer，这种机制可以改变数据流，实现 异步 action，日志输出，异常报告

### 1.2 redux-saga

redux-saga 是一个用于管理应用程序 Side Effect 的 library，它的目的是让 Side Effect 管理更加的简单、执行更高效。

redux-saga 是 redux 的 middleware，可以通过正常的 redux action 从主应用程序启动，暂停和取消，他可以访问完整的 redux state，也能够 dispatch redux action。

redux-saga 使用了 ES6 的 Generator 函数让异步更加易于读取、写入和测试。通过这种方式，让异步看起来更加像标准同步的 js 代码（async/await）。

## 2. redux-saga 的 API 介绍

### 2.1 Middleware API

- createSagaMiddleware(options) 创建一个 Redux Middleware，并将 Sagas 连接到 Redux Store，通过 createStore 第三个参数传入

> options： 传递给 middleware 的选项列表，默认可以不传递

- middleware.run(saga, ..arg) 动态地运行 saga，只能用于在 applyMiddleware 阶段之后执行 saga

### 2.2 redux-saga 的辅助函数

- takeEvery(pattern, saga, ...args) 在发起（dispatch）到 Store 并且匹配 pattern 的每一个 action 上派生一个 saga
- takeLatest(pattern, saga, ...args) 在发起到 Store 并且匹配 pattern 的每一个 action 上派生一个 saga。并自动取消之前所有已经启动但仍在执行中的 saga 任务
- throttle(ms, pattern, saga, ...args) 在发起到 Store 并且匹配 pattern 的一个 action 上派生一个 saga，它派生一次任务之后，仍然将新传入的 action 接收到底层的 buffer 中，至少保留（最近的）一个。但与此同时，它在 ms 毫秒内将暂停派生新的任务——这也就是它被命名问节流（throttle）的原因

这三个函数都是监听 action 的，只要 action 发送过来，就会触发对应的 saga 函数调用

### 2.3 Effect 创建器

- select(selector, ...args) 获取 redux 中的 state，如果调用 select 的参数是空的（即 yiled select()），那么 effect 会取得完整的 state（与调用 getSatte() 的结果相同）
- call(fn, ...args) 创建一个 effect 描述信息，用来命令 middleware 以参数 args 调用 fn
- take(partern) 阻塞的方法，用来匹配发出的 action
- put(partern) 用来命令 middleware 向 store 发起一个 action。这个 effect 是非阻塞型的。

## 案例

- 安装 redux-saga
- 在 store 目录中创建 sagas 目录
- 创建 loginSaga.js 和 listSaga.js 分别来对俩个页面的异步进行处理
- 在 sagas/index.js 中利用 all 副作用函数 同时来运行 loginSaga 和 listSaga
- 在 store/index.js 中关联 saga
- 利用 niddleware.run 来运行默认的 saga

### 实现 login 功能

- 需要在 loginReduer 里面判断匹配的 action，然后不需要做任何处理，直接把发送过来的 action 进行 ruturn
- 在 loginSaga 里面利用 takeEvery 来进行 action 的监听
- 利用 select 来获取发送过来的数据
- 安装 axios
- 利用 call 异步调用
- 获取数据，利用 put 副作用来发送请求成功的 action
- 如果获取失败，利用 put 来发送请求失败的 action

### 实现 list 功能

- 当 list 页面一加载时，发送 action，去请求列表数据
- 在 listRenducer 里面判断匹配的 action，如果是异步 action，如果是异步 ，直接把数据 ruturn
- 在 listSaga 里面利用 takeEvery 来进行 action 的监听
- 利用 call 异步调用
- 利用 put 副作用来发送请求成功的 action
- 如果失败，利用 put 来发送请求失败的 action
- 在 listRenducer 里面处理 发送请求
