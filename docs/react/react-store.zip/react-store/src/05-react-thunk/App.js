import { connect } from 'react-redux'
import ReactRedux from './ReactRedux'
import { increment, decrement, incrementAsync } from './redux/actions'

/*
// 将 redux 中的 state 数据映射成UI组件中的一般属性
function mapStateToProps(state) {
  return {
    count: state
  }
}

// 将 redux 中的包含 dispatch 代码的函数映射成UI组件中的一般方法
function mapDispatchToProps(dispatch) {
  return {
    increment: number => dispatch(increment(number)),
    decrement: number => dispatch(decrement(number))
  }
}

// const mapDispatchToProps = { increment, decrement }

// export default connect(mapStateToProps, mapDispatchToProps)(ReactRedux)

*/

// 最终版本
export default connect(state => ({ count: state.count }), { increment, decrement, incrementAsync })(
  ReactRedux
)
