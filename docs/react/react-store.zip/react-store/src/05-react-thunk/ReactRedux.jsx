import React, { Component } from 'react'
import PropTypes from 'prop-types'

export default class ReactRedux extends Component {
  static propTypes = {
    count: PropTypes.number.isRequired,
    increment: PropTypes.func.isRequired,
    decrement: PropTypes.func.isRequired,
    incrementAsync: PropTypes.func.isRequired
  }

  constructor(props) {
    super(props)
    // 创建ref，将其赋值给一个变量，通过ref挂载在dom节点或组件上，该ref的current属性将能拿到dom节点或组件的实例
    this.numberRef = React.createRef()
  }

  increment = () => {
    // 同步加
    const number = this.numberRef.current.value * 1
    this.props.increment(number)
  }

  decrement = () => {
    // 同步减
    const number = this.numberRef.current.value * 1
    this.props.decrement(number)
  }

  incrementIfOdd = () => {
    // 奇数加
    const number = this.numberRef.current.value * 1
    const count = this.props.count
    if (count % 2 === 1) {
      this.props.increment(number)
    }
  }

  incrementAsync = () => {
    const number = this.numberRef.current.value * 1
    this.props.incrementAsync(number)
  }

  render() {
    console.log(222, this.props)
    const count = this.props.count
    return (
      <div
        style={{ border: '2px solid blue', padding: 20, textAlign: 'center' }}
      >
        <p>react状态 | click {count} times</p>
        <div>
          <select ref={this.numberRef}>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
          </select>{' '}
          &nbsp;&nbsp;
          <button onClick={this.increment}>+</button>&nbsp;&nbsp;
          <button onClick={this.decrement}>-</button>&nbsp;&nbsp;
          <button onClick={this.incrementIfOdd}>奇数时增加</button>
          &nbsp;&nbsp;
          <button onClick={this.incrementAsync}>异步增加</button>
        </div>
      </div>
    )
  }
}
