// action 对象的 type 常量名称模块

export const INCREMENT = 'increment'
export const DECREMENT = 'decrement'
