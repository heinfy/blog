import { createStore } from 'redux'

import reducer from './reducer'

let store = createStore(reducer)

export default store // 创建 store 对象内部会第一次调用 reducer() 得到初始状态值
