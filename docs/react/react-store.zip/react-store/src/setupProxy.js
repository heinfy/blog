const { createProxyMiddleware } = require('http-proxy-middleware')

module.exports = function (app) {
  app.use(
    createProxyMiddleware('/publicApi', {
      target: 'http://activity-qa.xuebadev.com/publicApi', // 目标路径
      changeOrigin: true,
      secure: false,
      pathRewrite: {
        "^/publicApi": "/publicApi"
       }
    })
  )
  app.use(
    createProxyMiddleware('/api', {
      target: 'http://49.235.41.140:5000', // 目标路径
      changeOrigin: true,
      secure: false,
      pathRewrite: {
        "^/api": ""
       }
    })
  )
}
