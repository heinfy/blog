import React from 'react'
import { Provider, createStore, connect } from './redux'
import { connectToUser } from './connecters/connectToUser'
import './app.css'

const reducer = (state, { type, payload }) => {
  if (type === 'updateUser') {
    return {
      ...state,
      user: {
        ...state.user,
        ...payload
      }
    }
  } else {
    return state
  }
}
const initState = {
  user: { name: 'houfei', age: 18 },
  group: { name: '前端组' }
}

// 初始化状态，然后传到组件中
// const store = createStore(reducer, initState, applyMiddleware([reduxThunk, reduxPromise]))
const store = createStore(reducer, initState)

const 大儿子 = () => {
  console.log('大儿子执行了：', Math.random())
  return (
    <div className='big-son son'>
      大儿子
      <User />
    </div>
  )
}

const 二儿子 = () => {
  console.log('二儿子执行了：', Math.random())
  return (
    <div className='little-son son'>
      二儿子
      {/* 如果包涵了其他属性 */}
      <UserModifier x={'x'} y={'y'}>
        <div>子内容</div>
      </UserModifier>
    </div>
  )
}

const 三儿子 = connect(state => {
  return { group: state.group }
})(({ group }) => {
  console.log('三儿子执行了：', Math.random())
  return (
    <div className='small-son son'>
      三儿子
      <p>Group：{group.name}</p>
    </div>
  )
})

const User = connectToUser(({ user }) => {
  console.log('User执行了：', Math.random())
  return <div>User Name: {user.name}</div>
})

const UserModifier = connectToUser(({ updateUser, user, x, y, children }) => {
  console.log('UserModifier执行了：', Math.random())
  const onChange = e => {
    updateUser({ name: e.target.value })
  }
  return (
    <div>
      {children}
      <input type='text' value={user.name} onChange={onChange} />
    </div>
  )
})

// const fetchUser = dispatch => {
//   setTimeout(() => {
//     dispatch({
//       type: 'updateUser',
//       payload: '3秒后的 houfei'
//     })
//   }, 3000);
// }

// const UserModifier = connect(null, null)(({ state, dispatch }) => {
//   console.log('UserModifier执行了：', Math.random())
//   const onclick = () => {
//     dispatch({
//       type: 'updateUser',
//       payload: () => {
//         return setTimeout(() => {
//           return '3秒后的 houfei'
//         }, 3000);
//       }
//     })
//   }
//   return (
//     <div>
//       <div>User: {state.user.name}</div>
//       <button onClick={onclick}>异步获取 user</button>
//     </div>
//   )
// })

const App = () => {
  return (
    <Provider store={store}>
      <大儿子 />
      <二儿子 />
      <三儿子 />
    </Provider>
  )
}

export default App
