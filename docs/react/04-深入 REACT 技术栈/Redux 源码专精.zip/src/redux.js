import React, { useState, useEffect } from 'react'

let state = undefined ,reducer = undefined ,listeners = []

const setState = newState => {
  state = newState
  listeners.map(fn => fn(state))
}

const store = {
  getState() {
    return state
  },
  dispatch:  action => {
    setState(reducer(state, action))
  },
  // 订阅
  subscribe(fn) {
    listeners.push(fn)
    // 取消订阅
    return () => {
      const index = listeners.indexOf(fn)
      listeners.splice(index, 1)
    }
  }
}

let dispatch = store.dispatch

// const prevDispatch = dispatch

// dispatch = action => {
//   if(action instanceof Function) {
//     action(dispatch)
//   } else {
//     prevDispatch(action)
//   }
// }

// const prevDispatch2 = dispatch

// dispatch = action => {
//   if(action.payload instanceof Promise) {
//     action.payload.then(data => {
//       dispatch({...action, payload: data})
//     })
//   } else {
//     prevDispatch2(action)
//   }
// }

export const createStore = (_reducer, initState) => {
  state = initState
  reducer = _reducer
  return store
}
// 做一下新旧数据的对比
const changed = (oldState, newState) => {
  let changed = false
  for(let key in oldState) {
    if(oldState[key] !== newState[key]) {
      changed = true
    }
  }
  return changed
}

// 这里应该接受组件为参数，返回新的组件
// 增加一个新的参数， selector 让组件快速获取局部的 state
export const connect = (selector, dispatchSelector ) => Component => {
  // props 获取原组件上的属性，并传递给 connect 包装后的组件
  return props => {
    const [, update] = useState({})
    const data = selector ? selector(state) : {state}
    const dispatchers = dispatchSelector ? dispatchSelector(dispatch): {dispatch}
    // 只在第一次的时候进行订阅
    useEffect(() => {
      const unsubscribe =store.subscribe(() => {
        const newData = selector ? selector(state) : {state}
        if(changed(data, newData)) {
          console.log('update');
          update({})
        }
      })
      // 注意这里最好取消订阅，否则在 selector 变化时会出现重复订阅
      // 这里可以优化一下代码，现在不做优化，否则看不懂代码了
      // 如果 selector 更新了，取消之前的订阅，订阅新的订阅
      return unsubscribe
    }, [selector])
    return <Component {...props} {...data} {...dispatchers} />
  }
}

const appContext = React.createContext(null)

export const Provider = ({store, children}) => {
  return (
    <appContext.Provider value={store}>
      {children}
  </appContext.Provider>
  )
}
